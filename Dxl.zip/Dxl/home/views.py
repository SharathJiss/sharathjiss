from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from .models import Customer
import requests
from bs4 import BeautifulSoup
from .forms import CustomerForm
from textblob import TextBlob
import tweepy
# Create your views here.


def entry(request):
    return render(request, 'login.html')


def login(request):

    if (request.method == 'POST'):
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            cust = Customer.objects.all()

            return render(request, "home.html", {'customer': cust})
        else:
            messages.info(request, 'Invalid Credentials')
            return redirect('/')
    else:
        cust = Customer.objects.all()

        return render(request, "home.html", {'customer': cust})


def logout(request):
    auth.logout(request)
    return redirect('/')


def web(request, id):
    id1 = int(id)
    db = Customer.objects.get(id=id1)

    r = requests.get(db.url)
    soup = BeautifulSoup(r.content, 'html5lib')
    headings = soup.find_all('p')
    data = []
    for i in headings:
        data.append(i.text)
        str1 = ""

        for ele in data:
            str1 += ele

            str2 = str(str1)
        save = Customer(id=id1, customer_name=db.customer_name,
                        url=db.url, desc=str2,image=db.image)

        save.save()

    return render(request, "web.html", {'headings': data, 'name': db})


def register(request):

    cust = Customer.objects.all()
    form = CustomerForm(request.POST or None)
    
    if form.is_valid():
        form.image=form.cleaned_data['image']
        form.save()
        return render(request, 'home.html', {'customer': cust})
    return render(request, 'registeration.html', {'form': form, 'customer': cust})


def chat(request):
    return render(request, 'chat.html')


def analysis(request):
    consumer_key = 'KUfZSwAusULYroA7SRCrr7ZmC'
    consumer_secret = 'pN0KbKce8K3SeVbPeysok7QwnOaKunVpILvZaAekadGapOOiVH'
    access_token = '540847810-6Cm5VBo5pRNhPqrDAX1nKwmcJ2zj8E5pd5EnzcT1'
    access_token_secret = '2Cg5nRTPxPMnu4RTdClFA0ujD3EoumvSNRa45EKZjm5aG'

    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    api = tweepy.API(auth)


#  cust = Customer.objects.all()
    data1 = []
    data2 = []
    cust = Customer.objects.all()
    for i in cust:
        tweets = api.search(i.customer_name)

        for tweet in tweets:

            analysis = TextBlob(tweet.text)
            # print(analysis.sentiment)
            data1.append(analysis.sentiment.polarity)
            data2.append(analysis.sentiment.subjectivity)
            # print (data1)
            # print (data2)
            avg1 = sum(data1)/(len(data1))
            avg2 = sum(data2)/(len(data2))
            print("Average is")
            print(avg1)
            print(avg2)
            save = Customer(id=i.id, customer_name=i.customer_name,image=i.image,
                            url=i.url, desc=i.desc, polarity=avg1, subjectivity=avg2)
            save.save()

    return render(request, 'analysis.html')
