from django.urls import path
from . import views

urlpatterns = [
    
    path('',views.login,name='login'),
    path('logout',views.logout,name='logout'),
    path('home/<id>/',views.web,name='scrap'),
    path('register',views.register,name='register'),
    path('chat/',views.chat,name='chat'),
    path('analysis/',views.analysis,name='analysis')
    
    
    # path('drop',views.drop,name='drop')
    # path('british',views.british,name='b'),
    # path('qantas',views.qantas,name='b'),
    # path('expedia',views.expedia,name='b')
    
    
    ]