from django.db import models

# Create your models here.
class Customer(models.Model):
    customer_name=models.CharField(max_length=50)
    image=models.ImageField(upload_to='images',null=True,blank='True')
    desc=models.TextField(null=True,blank=True)
    url=models.TextField(null=True,blank=True)
    polarity =models.FloatField(null=True,blank=True)
    subjectivity =models.FloatField(null=True,blank=True)
