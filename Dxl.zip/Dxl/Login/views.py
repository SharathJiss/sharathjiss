from django.shortcuts import render
from .models import LoginModel
from django.contrib.auth.models import User,auth

# Create your views here.
def entry(request):
    return render(request,'login.html')
     
     
     
    